
import { BrowserRouter as Router, Route, Routes} from 'react-router-dom';
import { ToastContainer} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Signup } from './register';
import { Login } from './login';

const App = () => {
  return (
    <Router>
      <div className="min-h-screen bg-gray-900 flex items-center justify-center" style={{backgroundImage: "url('/api/placeholder/1920/1080')", backgroundSize: 'cover', backgroundPosition: 'center'}}>
        <Routes>
          <Route path="/" element={<Login />} />    
          <Route path="/signup" element={<Signup />} />
          <Route path="/login" element={<Login />} />
        </Routes>
        <ToastContainer position="bottom-right" theme="dark"/>
      </div>
    </Router>
  );
};


export default App;