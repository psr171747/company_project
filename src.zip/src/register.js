import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export const Signup = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [nickname, setNickname] = useState('');
  const navigate = useNavigate();

  const handleSignup = (e) => {
    e.preventDefault();
    if (!isPasswordValid(password)) {
      toast.error('Password must contain at least 8 characters with both numbers and letters.');
      return;
    }
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    if (users.some(user => user.email === email)) {
      toast.error('User already exists!');
      return;
    }
    users.push({ email, password });
    localStorage.setItem('users', JSON.stringify(users));
    toast.success('Registration successful!');
    navigate('/login');
  };

  const isPasswordValid = (password) => {
    const regex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
    return regex.test(password);
  };

  return (
    <div className="bg-gray-800 rounded-lg shadow-lg flex w-1/2">
      <div className="w-full flex items-center justify-center">
        <img src="/register.png" alt="Register" className="w-32 max-h-full" />
      </div>
      <div className="w-full p-8">
        <div className='flex justify-between align-middle border-b border-gray-300 pb-4 mb-4'>
          <div className="flex gap-5">
            <Link to="/login" className="text-gray-400 hover:text-gray-200">Login</Link>
            <span className="text-red-500 font-bold">Register</span>
          </div>
          <Link to="/" className='text-gray-400 hover:text-gray-200'>X</Link>
        </div>
        <div className="text-center mb-8">
          <p className="text-gray-400 mt-2">Your first step to sell and buy skins!</p>
        </div>
        <form onSubmit={handleSignup}>
          <div className="mb-4">
            <input
              type="email"
              placeholder="E-mail address"
              className="w-full px-3 py-2 bg-gray-700 text-white rounded"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="mb-4">
            <input
              type="password"
              placeholder="Password"
              className="w-full px-3 py-2 bg-gray-700 text-white rounded"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <div className="mb-6">
            <input
              type="text"
              placeholder="Nickname"
              className="w-full px-3 py-2 bg-gray-700 text-white rounded"
              value={nickname}
              onChange={(e) => setNickname(e.target.value)}
              required
            />
          </div>
          <p className='text-gray-400 mb-3 text-sm'>
            By signing up, you agree to GoSkins's <Link to="/privacy" className='text-blue-500 hover:underline'>Privacy Policy</Link> and <Link to="/terms" className='text-blue-500 hover:underline'>Terms of Service</Link>.
          </p>
          <button
            type="submit"
            className="w-full bg-red-500 text-white py-2 rounded hover:bg-red-600 transition duration-300"
          >
            Register
          </button>
        </form>
        <div className="mt-6">
          <button className="w-full bg-gray-700 text-white py-2 rounded hover:bg-gray-600 transition duration-300 mb-2">
            Sign up with Steam
          </button>
          <button className="w-full bg-gray-700 text-white py-2 rounded hover:bg-gray-600 transition duration-300">
            Sign up with Google
          </button>
        </div>
      </div>
    </div>
  );
};