import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'

export const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find(u => u.email === email && u.password === password);
    if (user) {
      toast.success('Login successful!');
      navigate('/');
    } else {
      toast.error('Invalid credentials or user not registered!');
    }
  };

  return (
    <div className="bg-gray-800 rounded-lg shadow-lg flex w-1/2">
      <div className="w-full flex items-center justify-center">
        <img src="/login.png" alt="Login" className="w-32 max-h-full" />
      </div>
      <div className="w-full p-8">
       <div className='flex justify-between align-middle'>
       <div className="flex gap-5 mb-8">
          <span className="text-green-500 font-bold">Login</span>
          <Link to="/signup" className="text-gray-400 hover:text-gray-200">Register</Link>
        </div>
        <Link className='text-gray-400'>X</Link>
       </div>
        <div className="text-center mb-8">
          <p className="text-gray-400 mt-2">Welcome back!</p>
          <p className="text-gray-400">Hope you have a FUNtastic day!</p>
        </div>
        <form onSubmit={handleLogin}>
          <div className="mb-4">
            <input
              type="email"
              placeholder="E-mail address"
              className="w-full px-3 py-2 bg-gray-700 text-white rounded"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="mb-6">
            <input
              type="password"
              placeholder="Password"
              className="w-full px-3 py-2 bg-gray-700 text-white rounded"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <button
            type="submit"
            className="w-full bg-green-500 text-white py-2 rounded hover:bg-green-600 transition duration-300"
          >
            Login
          </button>
        </form>
        <div className="mt-6">
          <button className="w-full bg-gray-700 text-white py-2 rounded hover:bg-gray-600 transition duration-300 mb-2">
            Login with Steam
          </button>
          <button className="w-full bg-gray-700 text-white py-2 rounded hover:bg-gray-600 transition duration-300">
            Login with Google
          </button>
        </div>
      </div>
    </div>
  );
};